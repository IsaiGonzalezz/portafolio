import type { NextConfig } from "next";

const config: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // En desarrollo, Next bloquea el JavaScript si abres el sitio desde un origen distinto de localhost
  // (por ejemplo 127.0.0.1 o la IP de tu red). Sin JavaScript la página se ve pero no responde.
  allowedDevOrigins: ["127.0.0.1", "localhost", "*.local", ...(process.env.ALLOWED_DEV_ORIGINS?.split(",").map((s) => s.trim()).filter(Boolean) ?? [])],
  async redirects() {
    return [{ source: "/", destination: "/es", permanent: false }];
  },
};

export default config;
